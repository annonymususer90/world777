module.exports = {
    defaultPassword: 'Abcd@332211',
}